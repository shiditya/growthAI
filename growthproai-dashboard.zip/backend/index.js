const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const headlines = [
  "Why Cake & Co is Mumbai's Sweetest Spot in 2025",
  "Discover the Magic of Cake & Co in Mumbai",
  "Top 5 Reasons Locals Love Cake & Co",
];

app.post('/business-data', (req, res) => {
  const { name, location } = req.body;
  const randomHeadline = headlines[Math.floor(Math.random() * headlines.length)];
  res.json({ rating: 4.3, reviews: 127, headline: randomHeadline });
});

app.get('/regenerate-headline', (req, res) => {
  const randomHeadline = headlines[Math.floor(Math.random() * headlines.length)];
  res.json({ headline: randomHeadline });
});

app.listen(5000, () => {
  console.log("✅ Backend server running at http://localhost:5000");
});
