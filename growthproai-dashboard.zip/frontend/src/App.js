import { useState } from "react";
import BusinessForm from "./components/BusinessForm";
import BusinessCard from "./components/BusinessCard";

function App() {
  const [businessData, setBusinessData] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold text-center mb-4">📊 Business Dashboard</h1>
      <BusinessForm setBusinessData={setBusinessData} />
      {businessData && (
        <BusinessCard data={businessData} setBusinessData={setBusinessData} />
      )}
    </div>
  );
}

export default App;
