function BusinessCard({ data, setBusinessData }) {
  const regenerateHeadline = async () => {
    const res = await fetch(`http://localhost:5000/regenerate-headline?name=${data.name}&location=${data.location}`);
    const result = await res.json();
    setBusinessData({ ...data, headline: result.headline });
  };

  return (
    <div className="bg-white p-4 mt-4 rounded shadow-md">
      <h2 className="text-xl font-semibold">{data.name} – {data.location}</h2>
      <p>⭐ Rating: {data.rating} ({data.reviews} reviews)</p>
      <p className="mt-2 font-medium italic">"{data.headline}"</p>
      <button
        onClick={regenerateHeadline}
        className="mt-3 bg-green-500 text-white px-3 py-1 rounded"
      >
        Regenerate SEO Headline
      </button>
    </div>
  );
}

export default BusinessCard;
